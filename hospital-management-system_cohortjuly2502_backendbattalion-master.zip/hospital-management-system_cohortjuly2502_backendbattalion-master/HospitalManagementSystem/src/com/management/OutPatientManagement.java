package com.management;

import java.sql.*;
import java.util.List;

import com.model.OutPatient;
import com.exception.HospitalManagementException;

public class OutPatientManagement {

    //Insert OutPatient List (Batch Processing)
    public static int insertOutPatientListDB(List<OutPatient> opPatientList)     
            throws HospitalManagementException {

        
        String sql = "INSERT INTO outpatient VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            for (OutPatient op : opPatientList) {
                ps.setString(1, op.getPatientId());
                ps.setString(2, op.getPatientName());
                ps.setLong(3, op.getPhoneNumber());
                ps.setInt(4, op.getAge());
                ps.setString(5, op.getGender());
                ps.setString(6, op.getMedicalHistory());
                ps.setString(7, op.getPreferredSpecialist());
                ps.setDouble(8, op.getMedicineFee());
                ps.setString(9, op.getPatientType());
                ps.setDouble(10, op.getRegistrationFees());
              
                ps.addBatch();
            }
            int[] rows=ps.executeBatch();
            return rows.length;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while inserting outpatient records: " + e.getMessage());
        } 
    }

    //Check if OutPatient ID Exists
    public static boolean checkIdExistsDB(String patientId) throws HospitalManagementException {
        
        String sql = "SELECT PATIENT_ID FROM outpatient WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } 
        catch(SQLException e) {
        	throw new HospitalManagementException("Error while checking Out Patient ID: "+e.getMessage());
        }
    }

    //Update OutPatient Phone Number
    public static int updateOutPatientPhoneNumberDB(String patientId, long newPhoneNumber)
            throws HospitalManagementException {

        
        String sql = "UPDATE outpatient SET PHONE_NUMBER = ? WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, newPhoneNumber);
            ps.setString(2, patientId);
            int updated = ps.executeUpdate();
            
            if (updated == 0)
                throw new HospitalManagementException("Patient ID not found for update!");
            return updated;
        } catch(SQLException e) {
        	throw new HospitalManagementException("Error while updating Out Patient phone number: "+e.getMessage());
        }
    }



    //Retrieve OutPatient Details
    public static OutPatient retrieveOutPatientDetailsDB(String patientId)
            throws HospitalManagementException {

        
        String sql = "SELECT * FROM outpatient WHERE PATIENT_ID = ?";
        OutPatient op = null;

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                op = new OutPatient();
                op.setPatientId(rs.getString("PATIENT_ID"));
                op.setPatientName(rs.getString("PATIENT_NAME"));
                op.setPhoneNumber(rs.getLong("PHONE_NUMBER"));
                op.setAge(rs.getInt("AGE"));
                op.setGender(rs.getString("GENDER"));
                op.setMedicalHistory(rs.getString("MEDICAL_HISTORY"));
                op.setPreferredSpecialist(rs.getString("PREFFERED_SPECIALIST"));
                op.setMedicineFee(rs.getDouble("MEDICINE_FEE"));
                op.setPatientType(rs.getString("PATIENT_TYPE"));
                op.setRegistrationFees(rs.getDouble("REGISTRATION_FEES"));
              
            }
            return op;
        } 
        catch(SQLException e) {
        	throw new HospitalManagementException("Error while retrieving Out Patient phone number: "+e.getMessage());
        }
    }

    //Delete OutPatient Record
    public static int deleteOutPatientDetailsFromDB(String patientId)
            throws HospitalManagementException {

        
        String sql = "DELETE FROM outpatient WHERE PATIENT_ID = ?";

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            int deleted = ps.executeUpdate();
            return deleted;
        } catch(SQLException e) {
        	throw new HospitalManagementException("Error while Deleting Out Patient phone number: "+e.getMessage());
        }
    }

	public static int retrieveOutPatientId() throws HospitalManagementException {
		
		
		String selectDoctorId="select max(cast(substring(patient_id,3) as unsigned)) from outpatient;";
		Statement st;
		try (Connection conn=DBConnectionManager.getConnection();){
			st = conn.createStatement();
			ResultSet rs=st.executeQuery(selectDoctorId);
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch(SQLException e) {
        	throw new HospitalManagementException("Error while Deleting Out Patient phone number: "+e.getMessage());
        }
		return 0;
	}
}
