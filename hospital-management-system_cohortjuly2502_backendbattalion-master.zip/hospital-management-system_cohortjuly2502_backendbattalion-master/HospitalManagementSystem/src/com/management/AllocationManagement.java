package com.management;

import java.sql.*;
import java.time.LocalDate;

import com.exception.HospitalManagementException;
import com.model.Allocation;

public class AllocationManagement {

    public static int retrieveAllocationId() throws HospitalManagementException {
        String query = "SELECT MAX(CAST(SUBSTRING(allocation_id,3) AS UNSIGNED)) FROM allocation;";
        try (Connection conn = DBConnectionManager.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving Allocation ID: " + e.getMessage());
        }
        return 0;
    }

    public static int insertAllocationList(Allocation alloc) throws HospitalManagementException {
        String insertSQL = "INSERT INTO allocation VALUES (?, ?, ?, ?, ?, ?, ?, ?,?);";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(insertSQL)) {

            ps.setString(1, alloc.getAllocationId());
            ps.setString(2, alloc.getPatientId());
            ps.setInt(3, alloc.getRoomNumber());
            ps.setInt(4, alloc.getNoOfDaysAdmitted());
            ps.setDate(5, java.sql.Date.valueOf(alloc.getAdmissionDate()));
            ps.setDate(6, java.sql.Date.valueOf(alloc.getDischargeDate()));
            ps.setString(7, alloc.getTreatment());
            ps.setString(8, alloc.getRoomType());
            ps.setString(9, alloc.getWantFood());


            int rows = ps.executeUpdate();
            return rows;

        } catch (SQLException e) {
            throw new HospitalManagementException("Error while inserting Allocation details: " + e.getMessage());
        }
    }

    public static boolean checkIdExists(String allocationId) throws HospitalManagementException {
        String query = "SELECT COUNT(*) FROM allocation WHERE allocation_id = ?;";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, allocationId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while checking Allocation ID: " + e.getMessage());
        }
        return false;
    }

    public static Allocation retrieveAllocationDetailsFromDB(String patientId) throws HospitalManagementException {
        String query = "SELECT * FROM allocation WHERE patient_id = ?;";

        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();
            
            Allocation al=null;
            if(rs.next()) {
                 al = new Allocation(
                        rs.getString("allocation_id"),
                        rs.getString("patient_id"),
                        rs.getInt("room_number"),
                        rs.getInt("NO_OF_DAYS_ADMITTED"),
                        rs.getDate("admission_date").toLocalDate(),
                        rs.getDate("discharge_date").toLocalDate(),
                        rs.getString("treatment"),
                        rs.getString("room_type"),
                        rs.getString("WANT_FOOD")
                );  
            }
            return al;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error retrieving allocation details: " + e.getMessage());
        }       
    }

    public static int deleteAllocationDetailsFromDB(String patientId) throws HospitalManagementException {
        String query = "DELETE FROM allocation WHERE patient_id = ?;";
        try (Connection conn = DBConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, patientId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new HospitalManagementException("Error deleting allocation details: " + e.getMessage());
        }
    }

	public static int updateDischargeDateDB(String patientId, LocalDate dischargeDate,int noOfDays) throws HospitalManagementException {
		String sql = "UPDATE allocation SET DISCHARGE_DATE  = ?,NO_OF_DAYS_ADMITTED =? WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) { 
            ps.setDate(1, java.sql.Date.valueOf(dischargeDate));
            ps.setInt(2, noOfDays);
            ps.setString(3, patientId);
            int updated = ps.executeUpdate();
            
            return updated;
        } catch(SQLException e) {
        	throw new HospitalManagementException("Error while updating Out Patient phone number: "+e.getMessage());
        }
	}
}