package com.management;

import java.sql.*;
import java.util.List;

import com.model.InPatient;
import com.exception.HospitalManagementException;

public class InPatientManagement {

    //Insert InPatient List (Batch Processing)
    public static int insertInPatientListDB(List<InPatient> inPatientList)     
            throws HospitalManagementException {

        
        String sql = "INSERT INTO inpatient VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            for (InPatient ip : inPatientList) {
                ps.setString(1, ip.getPatientId());
                ps.setString(2, ip.getPatientName());
                ps.setLong(3, ip.getPhoneNumber());
                ps.setInt(4, ip.getAge());
                ps.setString(5, ip.getGender());
                ps.setString(6, ip.getMedicalHistory());
                ps.setString(7, ip.getPreferredSpecialist());
                ps.setDouble(8, ip.getMedicineFee());
                ps.setString(9, ip.getPatientType());
                ps.setDouble(10, ip.getAdmissionFees());
                ps.setString(11, ip.getTreatment());
                ps.setString(12, ip.getRoomType());
                ps.setString(13, ip.getWantFood());
                ps.addBatch();
            }
            int[] rows=ps.executeBatch();
            return rows.length;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while inserting inpatient records: " + e.getMessage());
        }
    }

    //Check if InPatient ID Exists
    public static boolean checkIdExistsDB(String patientId) throws HospitalManagementException {
        
        String sql = "SELECT PATIENT_ID FROM inpatient WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch(SQLException e){
        	throw new HospitalManagementException("Error while Checking Patient ID : "+e.getMessage());
        }
    }

    //Update InPatient Phone Number
    public static int updateInPatientPhoneNumberDB(String patientId, long newPhoneNumber)
            throws HospitalManagementException {

        
        String sql = "UPDATE inpatient SET PHONE_NUMBER = ? WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, newPhoneNumber);
            ps.setString(2, patientId);
            int updated = ps.executeUpdate();
            
            return updated;
        } catch(SQLException e){
        	throw new HospitalManagementException("Error while Updating In Patient Phone Number: "+e.getMessage());
        }
    }

    //Update InPatient Room Type
    public static int updateInPatientRoomTypeDB(String patientId, String newRoomType)
            throws HospitalManagementException {

        
        String sql = "UPDATE inpatient SET ROOM_TYPE = ? WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newRoomType);
            ps.setString(2, patientId);
            int updated = ps.executeUpdate();
            return updated;
        }catch(SQLException e){
        	throw new HospitalManagementException("EError while Updating In Patient Room Type: "+e.getMessage());
        }
    }

    //Update InPatient Food Preference
    public static int updateInPatientFoodPreferenceDB(String patientId, String newFoodPref)
            throws HospitalManagementException {

        
        String sql = "UPDATE inpatient SET WANT_FOOD = ? WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newFoodPref);
            ps.setString(2, patientId);
            int updated = ps.executeUpdate();

            return updated;
        } 
        catch(SQLException e){
        	throw new HospitalManagementException("Error while Updating In Patient Food Preference: "+e.getMessage());
        }
    }

    //Retrieve InPatient Details
    public static InPatient retrieveInPatientDetailsDB(String patientId) throws HospitalManagementException {

        
        String sql = "SELECT * FROM inpatient WHERE PATIENT_ID = ?";
        InPatient ip = null;

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                ip = new InPatient();
                ip.setPatientId(rs.getString("PATIENT_ID"));
                ip.setPatientName(rs.getString("PATIENT_NAME"));
                ip.setPhoneNumber(rs.getLong("PHONE_NUMBER"));
                ip.setAge(rs.getInt("AGE"));
                ip.setGender(rs.getString("GENDER"));
                ip.setMedicalHistory(rs.getString("MEDICAL_HISTORY"));
                ip.setPreferredSpecialist(rs.getString("PREFFERED_SPECIALIST"));
                ip.setMedicineFee(rs.getDouble("MEDICINE_FEE"));
                ip.setPatientType(rs.getString("PATIENT_TYPE"));
                ip.setAdmissionFees(rs.getDouble("ADMISSION_FEES"));
                ip.setTreatment(rs.getString("TREATMENT"));
                ip.setRoomType(rs.getString("ROOM_TYPE"));
                ip.setWantFood(rs.getString("WANT_FOOD"));
            } 
            return ip;
        } catch(SQLException e){
        	throw new HospitalManagementException("Error while Retrieving In Patient details: "+e.getMessage());
        }
    }

    //Delete InPatient Record
    public static int deleteInPatientDetailsFromDB(String patientId) throws HospitalManagementException {
    
        String sql = "DELETE FROM inpatient WHERE PATIENT_ID = ?";

        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patientId);
            int rows = ps.executeUpdate();

            return rows;
        } 
        catch(SQLException e){
        	throw new HospitalManagementException("Error while Deleting In Patient details: "+e.getMessage());
        }
    }

	public static int retrieveInPatientId() throws HospitalManagementException {
		Connection conn=DBConnectionManager.getConnection();
		
		String selectDoctorId="select max(cast(substring(patient_id,3) as unsigned)) from inpatient;";
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rs=st.executeQuery(selectDoctorId);
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new HospitalManagementException("Error while retrieving In Patient ID: "+e.getMessage());
		}
		return 0;
	}

	public static int retrieveRoomCountByType(String roomType) throws HospitalManagementException {
		// find count for room type
		String selectRoomCount="select count(room_type) from inpatient where room_type=? group by room_type;";
		try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(selectRoomCount)) {
            ps.setString(1, roomType);
            ResultSet rs= ps.executeQuery();
            int rows=0;
            while(rs.next()) {
            	rows=rs.getInt(1);
            }

            return rows;
        } 
        catch(SQLException e){
        	throw new HospitalManagementException("Error while Retrieving room count by type In Patient details: "+e.getMessage());
        }
	}
}
