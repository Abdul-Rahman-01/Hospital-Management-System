package com.management;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import com.exception.HospitalManagementException;
import com.model.Appointment;

public class AppointmentManagement {

	
	public static int retrieveAppointmentId() throws HospitalManagementException{
		
		
		String selectAppointmentId="select max(cast(substring(appointment_id,3) as unsigned)) from appointment;";
		Statement st;
		try(Connection conn=DBConnectionManager.getConnection();){
			st = conn.createStatement();
			ResultSet rs=st.executeQuery(selectAppointmentId);
			if(rs.next()) {
				return rs.getInt(1);
			}
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while retrieving Appointment ID: "+e.getMessage());
		}
		
		return 0;
	}
	
    // Insert Appointment List (Batch insert)
    public static int insertAppointmentList(Appointment a) throws HospitalManagementException {
        String sql = "INSERT INTO appointment (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, DOCTOR_NAME, SPECIALIZATION, APPOINTMENT_DATE, APPOINTMENT_TIME, MODE_OF_APPOINTMENT) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, a.getAppointmentId());
                ps.setString(2, a.getPatientId());
                ps.setString(3, a.getDoctorId());
                ps.setString(4, a.getDoctorName());
                ps.setString(5, a.getSpecialization());
                ps.setDate(6, java.sql.Date.valueOf(a.getAppointmentDate()));
                ps.setTime(7, java.sql.Time.valueOf(a.getAppointmentTime()));
                ps.setString(8, a.getModeOfAppointment());
            int rows=ps.executeUpdate();
            return rows;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error adding appointment details into database : "+e.getMessage());
        }
    }

    // Retrieve Appointments for a Patient
    public static List<Appointment> retrieveAppointmentDetailsFromDB(String patientId) throws HospitalManagementException {
    	
    	List<Appointment> appointmentList=new ArrayList<Appointment>();
    	
        String sql = "SELECT * FROM appointment WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Appointment a = new Appointment();
                a.setAppointmentId(rs.getString("APPOINTMENT_ID"));
                a.setPatientId(rs.getString("PATIENT_ID"));
                a.setDoctorId(rs.getString("DOCTOR_ID"));
                a.setDoctorName(rs.getString("DOCTOR_NAME"));
                a.setSpecialization(rs.getString("SPECIALIZATION"));
                a.setAppointmentDate(rs.getDate("APPOINTMENT_DATE").toLocalDate());
                a.setAppointmentTime(rs.getTime("APPOINTMENT_TIME").toLocalTime());
                a.setModeOfAppointment(rs.getString("MODE_OF_APPOINTMENT"));
                appointmentList.add(a);
            }
            return appointmentList;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving appointment details: "+e.getMessage());
        }
    }

    // Delete Appointment by Patient ID
    public static int deleteAppointmentDetailsFromDB(String appointmentId) throws HospitalManagementException {
        String sql = "DELETE FROM appointment WHERE PATIENT_ID = ?";
        try (Connection con = DBConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, appointmentId);
            int rows = ps.executeUpdate();
            return rows;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while Deleting appointment details: "+e.getMessage());
        }
    }

	public static List<Appointment> retrieveAppointmentsByDoctorIdDB(String doctorId) throws HospitalManagementException {
		
		
		List<Appointment> appointmentListByDoctor=new ArrayList<Appointment>();
		
		String selectAppointmentDetailsByDoctorID="select * from appointment where doctor_id=?;";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(selectAppointmentDetailsByDoctorID)){
			ps.setString(1, doctorId);
			ResultSet rs=ps.executeQuery();
			
			
			while(rs.next()) {
				String appointmentId=rs.getString(1);
				String patientId=rs.getString(2);
				String doctorIdDB=rs.getString(3);
				String doctorName=rs.getString(4);
				String specialization=rs.getString(5);
				LocalDate availableDate=rs.getDate(6).toLocalDate();
				LocalTime availableTime=rs.getTime(7).toLocalTime();
				String modeOfAppointment=rs.getString(8);
				
				Appointment ap=new Appointment(appointmentId, patientId, doctorIdDB, doctorName, specialization, availableDate, availableTime, modeOfAppointment);
				
				appointmentListByDoctor.add(ap);
			}
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while Retrieving Appointment details by Doctor ID: "+e.getMessage());
		}
		return appointmentListByDoctor;
	}
}