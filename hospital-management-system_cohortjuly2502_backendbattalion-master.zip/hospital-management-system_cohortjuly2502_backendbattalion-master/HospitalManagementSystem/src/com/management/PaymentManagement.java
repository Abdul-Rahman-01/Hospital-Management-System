package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.time.*;

import com.exception.HospitalManagementException;
import com.model.Payment;

public class PaymentManagement {

	public static List<Payment> retrievePaymentDetailsByPatientDB(String patientId) throws HospitalManagementException{
		
		
        String selectQuery = "SELECT * FROM payment WHERE PATIENT_ID = ?";
        Payment p = null;
        
        List<Payment> paymentList=new ArrayList<Payment>();
        
        try (Connection con = DBConnectionManager.getConnection();
        		PreparedStatement ps = con.prepareStatement(selectQuery)) {
            ps.setString(1, patientId);
            ResultSet rs = ps.executeQuery();
            if(!rs.isBeforeFirst()) {
            	throw new HospitalManagementException("No Payment Details found for Patient ID: "+patientId);
            }
            else {
            	 while(rs.next()) {
                     String paymentId=rs.getString(1);
                     String patientIdDB=rs.getString(2);
                     String patientName=rs.getString(3);
                     String patientType=rs.getString(4);
                     LocalDate paymentDate=rs.getDate(5).toLocalDate();
                     String modeOfPayment=rs.getString(6);
                     double amount=rs.getDouble(7);
                     p=new Payment(paymentId, patientIdDB, patientName, patientType, paymentDate, modeOfPayment, amount);
                     paymentList.add(p);
                 }
            }
        } 
        catch(SQLException e) {
        	throw new HospitalManagementException("Error while retrieving Payment details by patient ID: "+e.getMessage());
        }
        return paymentList;
	}

	public static int retrievePaymentId() throws HospitalManagementException {
		
		
		String selectPaymentId="select max(cast(substring(payment_id,4) as unsigned)) from payment;";
		Statement st;
		try (Connection conn=DBConnectionManager.getConnection();){
			st = conn.createStatement();
			ResultSet rs=st.executeQuery(selectPaymentId);
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new HospitalManagementException("Payment Id not available");
		}
		return 0;
	}
	
	//inserting payment details
	public static int insertPaymentDB(Payment pay) throws HospitalManagementException {
	
		/*
		 PAYMENT_ID 
		PATIENT_ID 
		PATIENT_NAME 
		PATIENT_TYPE 
		PAYMENT_DATE 
		MODE_OF_PAYMENT 
		BILL_AMOUNT 
		 */
		String insertSQLQuery="insert into payment values(?,?,?,?,?,?,?);";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(insertSQLQuery)){
			
			ps.setString(1, pay.getPaymentId());
			ps.setString(2, pay.getPatientId());
			ps.setString(3, pay.getPatientName());
			ps.setString(4,pay.getPatientType());
			ps.setDate(5, java.sql.Date.valueOf(pay.getPaymentDate()));
			ps.setString(6, pay.getModeOfPayment());
			ps.setDouble(7, pay.getBillAmount());
			
			
			int rows= ps.executeUpdate();
			return rows;
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while inserting Payment details: "+e.getMessage());
		}
	}
	
	public static Payment retrievePaymentDetailsByPaymentIdDB(String paymentId) throws HospitalManagementException {
		
		
		String selectCheckPaymentId="select * from payment where payment_id=?;";
		
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(selectCheckPaymentId)){
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				String paymentIdDB=rs.getString(1);
                String patientId=rs.getString(2);
                String patientName=rs.getString(3);
                String patientType=rs.getString(4);
                LocalDate paymentDate=rs.getDate(5).toLocalDate();
                String modeOfPayment=rs.getString(6);
                double amount=rs.getDouble(7);
                return new Payment(paymentIdDB, patientId, patientName, patientType, paymentDate, modeOfPayment, amount);
			}
			else {
				throw new HospitalManagementException("Payment Id not available");
			}
		} catch (SQLException e) {
			throw new HospitalManagementException("Error while retrieving payment details by Payment Id: "+e.getMessage());
		}
	}
}
