package com.management;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.exception.HospitalManagementException;

public class DBConnectionManager {

	private static Connection conn=null;
	private static Properties prop=new Properties();
	
	public static Connection getConnection() throws HospitalManagementException {
		try {
			FileInputStream fis=new FileInputStream("DBCredentials.properties");
			prop.load(fis);
			
			Class.forName(prop.getProperty("DRIVER"));
			conn=DriverManager.getConnection(prop.getProperty("URL"), prop.getProperty("USERNAME"), prop.getProperty("PASSWORD"));
		}
		catch(IOException | SQLException |ClassNotFoundException e) {
			throw new HospitalManagementException("Connection not established: "+e.getMessage());
		}
		
		return conn;
	}

}
