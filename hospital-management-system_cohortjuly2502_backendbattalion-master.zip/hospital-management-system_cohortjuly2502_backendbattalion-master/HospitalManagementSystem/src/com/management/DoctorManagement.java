package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.exception.HospitalManagementException;
import com.model.Doctor;

public class DoctorManagement {
	
	public static int retrieveDoctorId() throws HospitalManagementException {
		
		
		String selectDoctorId="select max(cast(substring(doctor_id,4) as unsigned)) from doctor;";
		Statement st;
		try(Connection conn=DBConnectionManager.getConnection();) {
			st = conn.createStatement();
			ResultSet rs=st.executeQuery(selectDoctorId);
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new HospitalManagementException("Error while retrieving Doctor ID: "+e.getMessage());
		}
		return 0;
		
	}
	public static int insertDoctor(List<Doctor> docList) throws HospitalManagementException {
	
		/*
		 DOCTOR_ID 
		DOCTOR_NAME 
		DOCTOR_FEE 
		SPECIALIZATION 
		AVAILABLE_DATE 
		AVAILABLE_TIME 
		 */
		String insertSQLQuery="insert into doctor values(?,?,?,?,?,?);";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(insertSQLQuery)){
			for(Doctor doc:docList) {
				ps.setString(1,doc.getDoctorId());
				ps.setString(2, doc.getDoctorName());
				ps.setDouble(3, doc.getDoctorFee());
				ps.setString(4, doc.getSpecialization());
				//localDate into sql date
				ps.setDate(5, java.sql.Date.valueOf(doc.getAvailableDate()));
				//localTime into sql date
				ps.setTime(6, java.sql.Time.valueOf(doc.getAvailableTime()));
				ps.addBatch();
			}
			int rows[]= ps.executeBatch();
			return rows.length;
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while inserting doctor: "+e.getMessage());
		}
	}
		


	public static int updateDoctorFee(String doctorId, double doctorFee) throws HospitalManagementException {
		
		
		String updateSQLQuery="update doctor set doctor_fee=? where doctor_id=?;";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(updateSQLQuery)){
			ps.setDouble(1, doctorFee);
			ps.setString(2, doctorId);
			return ps.executeUpdate();
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while updating doctor's fees: "+e.getMessage());
		}
		
	}

	public static int updateDoctorAvailableDate(String doctorId, LocalDate updatedDate) throws HospitalManagementException {

		String updateSQLQuery="update doctor set available_date=? where doctor_id=?;";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(updateSQLQuery)){
			ps.setDate(1, java.sql.Date.valueOf(updatedDate)); //converting localDate to sqlDate
			ps.setString(2, doctorId);
			return ps.executeUpdate();
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while updating doctor's available date: "+e.getMessage());
		}

	}

	public static Doctor retrieveDoctorDetailsFromDB(String doctorId) throws HospitalManagementException {
		
		
		String selectSQLQuery="select * from doctor where doctor_id=?;";
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(selectSQLQuery)){
			ps.setString(1, doctorId);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				String id=rs.getString(1);
				String doctorName=rs.getString(2);
				double doctorFee=rs.getDouble(3);
				String specialization=rs.getString(4);
				LocalDate availableDate=rs.getDate(5).toLocalDate();
				LocalTime availableTime=rs.getTime(6).toLocalTime();
				Doctor doc=new Doctor(id,doctorName,doctorFee,specialization,availableDate,availableTime);
				return doc;
			}
			else {
				throw new HospitalManagementException("Doctor details not available: "+doctorId);
			}
			
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while retrieve details "+e.getMessage());
		}
	}
	public static List<Doctor> retrieveDoctorDetailsBySpecializationFromDB(String searchSpecialization) throws HospitalManagementException {
		
		
		String selectSQLQueryDocSpecialization="select * from doctor where specialization=?";
		
		List<Doctor> docListBySpecialization = new ArrayList<Doctor>();
		try(Connection conn=DBConnectionManager.getConnection();
				PreparedStatement ps=conn.prepareStatement(selectSQLQueryDocSpecialization)){
			ps.setString(1, searchSpecialization);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				String id=rs.getString(1);
				String doctorName=rs.getString(2);
				double doctorFee=rs.getDouble(3);
				String specialization=rs.getString(4);
				LocalDate availableDate=rs.getDate(5).toLocalDate();
				LocalTime availableTime=rs.getTime(6).toLocalTime();
				Doctor doc=new Doctor(id,doctorName,doctorFee,specialization,availableDate,availableTime);
				
				docListBySpecialization.add(doc);
			}
			return docListBySpecialization;
		}
		catch(SQLException e) {
			throw new HospitalManagementException("Error while retrieving doctor details by specialization: "+e.getMessage());
		}
	}
	
	
}
