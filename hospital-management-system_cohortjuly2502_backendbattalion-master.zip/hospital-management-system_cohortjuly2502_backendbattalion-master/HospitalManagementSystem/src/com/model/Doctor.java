package com.model;


import java.time.*;

public class Doctor {
    private String doctorId;
    private String doctorName;
    private double doctorFee;
    private String specialization;
    private LocalDate availableDate;
    private LocalTime availableTime;

    public Doctor()
    {
    	 
    }

    public Doctor(String doctorId, String doctorName, double doctorFee, String specialization, LocalDate availableDate,
			LocalTime availableTime) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorFee = doctorFee;
		this.specialization = specialization;
		this.availableDate = availableDate;
		this.availableTime = availableTime;
	}


    

	public String getDoctorId() {
		return doctorId;
	}




	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}




	public String getDoctorName() {
		return doctorName;
	}




	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}




	public double getDoctorFee() {
		return doctorFee;
	}




	public void setDoctorFee(double doctorFee) {
		this.doctorFee = doctorFee;
	}




	public String getSpecialization() {
		return specialization;
	}




	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}




	public LocalDate getAvailableDate() {
		return availableDate;
	}




	public void setAvailableDate(LocalDate availableDate) {
		this.availableDate = availableDate;
	}




	public LocalTime getAvailableTime() {
		return availableTime;
	}




	public void setAvailableTime(LocalTime availableTime) {
		this.availableTime = availableTime;
	}




	@Override
    public String toString() {
        return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", doctorFee=" + doctorFee +
                ", specialization=" + specialization + ", availableDate=" + availableDate +
                ", availableTime=" + availableTime + "]";
    }
}
