package com.model;

public class OutPatient extends Patient {
    private double registrationFees;

    public OutPatient()
    {
    	 
    }

    public OutPatient(String patientId, String patientName, long phoneNumber, int age, String gender,
			String medicalHistory, String preferredSpecialist, double medicineFee, String patientType,
			double registrationFees) {
		super(patientId, patientName, phoneNumber, age, gender, medicalHistory, preferredSpecialist, medicineFee,
				patientType);
		this.registrationFees = registrationFees;
	}



	public double getRegistrationFees() {
		return registrationFees;
	}



	public void setRegistrationFees(double registrationFees) {
		this.registrationFees = registrationFees;
	}



	@Override
    public String toString() {
        return "OutPatient [" + super.toString() + ", registrationFees=" + registrationFees + "]";
    }
}
