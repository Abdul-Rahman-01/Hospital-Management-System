package com.model;

import java.time.LocalDate;

public class Allocation {
    private String allocationId;
    private String patientId;
    private int roomNumber;
    private int noOfDaysAdmitted;
    private LocalDate admissionDate;
    private LocalDate dischargeDate;
    private String treatment;
    private String roomType;
    private String wantFood;

    public Allocation()
    {
    	 
    }

    public Allocation(String allocationId, String patientId, int roomNumber, int noOfDaysAdmitted, LocalDate admissionDate,
    		LocalDate dischargeDate, String treatment, String roomType, String wantFood) {
		super();
		this.allocationId = allocationId;
		this.patientId = patientId;
		this.roomNumber = roomNumber;
		this.noOfDaysAdmitted = noOfDaysAdmitted;
		this.admissionDate = admissionDate;
		this.dischargeDate = dischargeDate;
		this.treatment = treatment;
		this.roomType = roomType;
		this.wantFood = wantFood;
	}
    
    

	public String getAllocationId() {
		return allocationId;
	}



	public void setAllocationId(String allocationId) {
		this.allocationId = allocationId;
	}



	public String getPatientId() {
		return patientId;
	}



	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}



	public int getRoomNumber() {
		return roomNumber;
	}



	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}



	public int getNoOfDaysAdmitted() {
		return noOfDaysAdmitted;
	}



	public void setNoOfDaysAdmitted(int noOfDaysAdmitted) {
		this.noOfDaysAdmitted = noOfDaysAdmitted;
	}



	public LocalDate getAdmissionDate() {
		return admissionDate;
	}



	public void setAdmissionDate(LocalDate admissionDate) {
		this.admissionDate = admissionDate;
	}



	public LocalDate getDischargeDate() {
		return dischargeDate;
	}



	public void setDischargeDate(LocalDate dischargeDate) {
		this.dischargeDate = dischargeDate;
	}



	public String getTreatment() {
		return treatment;
	}



	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}



	public String getRoomType() {
		return roomType;
	}



	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}



	public String getWantFood() {
		return wantFood;
	}



	public void setWantFood(String wantFood) {
		this.wantFood = wantFood;
	}



	@Override
    public String toString() {
        return "Allocation [allocationId=" + allocationId + ", patientId=" + patientId + ", roomNumber=" + roomNumber +
                ", noOfDaysAdmitted=" + noOfDaysAdmitted + ", admissionDate=" + admissionDate +
                ", dischargeDate=" + dischargeDate + ", treatment=" + treatment +
                ", roomType=" + roomType + ", wantFood=" + wantFood + "]";
    }
}
