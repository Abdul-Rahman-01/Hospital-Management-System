package com.util;

import java.util.ArrayList;
import java.util.List;
import com.exception.HospitalManagementException;
import com.management.AllocationManagement;
import com.management.AppointmentManagement;
import com.management.DoctorManagement;
import com.management.InPatientManagement;
import com.management.OutPatientManagement;
import com.management.PaymentManagement;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ApplicationUtil {

	private static int doctorId=1000;
	private static int inPatientId=1000;
	private static int outPatientId=1000;
	private static int paymentId=1000;
	private static int appointmentId=1000;
	private static int allocationId=1000;

    public static int generateDoctorId() throws HospitalManagementException {
    	int docIdfromDB=DoctorManagement.retrieveDoctorId();
    	if(docIdfromDB>0) {
    		//docIdfromDB++;
    		return docIdfromDB;
    	}
    	//doctorId++;
    	return doctorId;
    }
    
    public static int generateInPatientId() throws HospitalManagementException {
    	int inPatientIdfromDB=InPatientManagement.retrieveInPatientId();
    	if(inPatientIdfromDB>0) {
    		//inPatientIdfromDB++;
    		return inPatientIdfromDB;
    	}
    	//inPatientId++;
    	return inPatientId;
    }
    
    public static String generatePaymentId() throws HospitalManagementException {
    	int payIdfromDB=PaymentManagement.retrievePaymentId();
    	if(payIdfromDB>0) {
    		payIdfromDB++;
    		return "PAY"+payIdfromDB;
    	}
    	paymentId++;
    	return "PAY"+paymentId;
    }
    
    public static int generateOutPatientId() throws HospitalManagementException {
    	int outPatientIdfromDB=OutPatientManagement.retrieveOutPatientId();
    	if(outPatientIdfromDB>0) {
    		//outPatientIdfromDB++;
    		return outPatientIdfromDB;
    	}
        //outPatientId++;
    	return outPatientId;
    }
    
    public static String generateAppointmentId() throws HospitalManagementException {
    	int appointmentIdfromDB=AppointmentManagement.retrieveAppointmentId();
    	if(appointmentIdfromDB>0) {
    		appointmentIdfromDB++;
    		return "AP"+appointmentIdfromDB;
    	}
        appointmentId++;
    	return "AP"+appointmentId;
    }
    
    public static String generateAllocationId() throws HospitalManagementException {
    	int allocationIdfromDB=AllocationManagement.retrieveAllocationId();
    	if(allocationIdfromDB>0) {
    		allocationIdfromDB++;
    		return "AL"+allocationIdfromDB;
    	}
        allocationId++;
    	return "AL"+allocationId;
    }
    
    public static void validateDoctorId(String doctorId) throws HospitalManagementException{
    	if(!doctorId.matches("[D][O][C][0-9]{4,}")) {
    		throw new HospitalManagementException("Invalid Doctor ID. Expected format: DOCXXXX");
    	}
    }

    public static void validateInPatientId(String patientId) throws HospitalManagementException {
        if (patientId == null || !patientId.matches("IP[0-9]{4,}")) {
            throw new HospitalManagementException("Invalid InPatient ID. Expected format: IPXXXX");
        }
    }
    
    public static void validateOutPatientId(String patientId) throws HospitalManagementException {
        if (patientId == null || !patientId.matches("OP[0-9]{4,}")) {
            throw new HospitalManagementException("Invalid OutPatient ID. Expected format: OPXXXX");
        }
    }
    
    public static void validatePaymentId(String paymentId) throws HospitalManagementException {
        if (paymentId == null || !paymentId.matches("PAY[0-9]{4,}")) {
            throw new HospitalManagementException("Invalid Payment ID. Expected format: PAYXXXX");
        }
    }
    
    public static void validateAppointmentId(String appointmentId) throws HospitalManagementException {
        if (appointmentId == null || !appointmentId.matches("AP[0-9]{4,}")) {
            throw new HospitalManagementException("Invalid Appointment ID. Expected format: APXXXX");
        }
    }
    
    public static void validateAllocationId(String allocationId) throws HospitalManagementException {
        if (allocationId == null || !allocationId.matches("AL[0-9]{4,}")) {
            throw new HospitalManagementException("Invalid Allocation ID. Expected format: ALXXXX");
        }
    }
    
    public static void validateFee(double fee) throws HospitalManagementException{
    	if(fee<0) {
    		throw new HospitalManagementException("Invalid Fee");
    	}
    }

    
    public static List<String> extractDetails(String input) throws HospitalManagementException {
        if (input == null || input.isEmpty()) {
            throw new HospitalManagementException("Input cannot be empty");
        }

        String[] parts = input.split(",");
        List<String> list = new ArrayList<>();
        for (String s : parts) {
            list.add(s.trim());  
        }
        return list;
    }
    
    public static LocalDate parseLocalDate(String dateStr) throws HospitalManagementException {
    	
    	try {
    		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            return LocalDate.parse(dateStr, formatter); //expects dd-MM-yyyy
        } 
    	catch (DateTimeParseException e) {
            throw new HospitalManagementException("Invalid date format. Expected dd-MM-yyyy");
        }
    }

    public static LocalTime parseLocalTime(String timeStr) throws HospitalManagementException {
    	try {
    		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            return LocalTime.parse(timeStr, formatter); //expects HH:mm
        } 
    	catch (DateTimeParseException e) {
            throw new HospitalManagementException("Invalid time format. Expected HH:mm");
        }
    }
    
    // Input validation example
    public static void validatePhoneNumber(String phone) throws HospitalManagementException {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new HospitalManagementException("Invalid phone number. Must be 10 digits.");
        }
    }

    public static void validateAge(int age) throws HospitalManagementException {
        if (age <= 0 || age > 120) {
            throw new HospitalManagementException("Invalid age. Must be between 1 and 120.");
        }
    }

    public static void validateGender(String gender) throws HospitalManagementException {
        if (gender == null || !(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female") || gender.equalsIgnoreCase("other"))) {
            throw new HospitalManagementException("Invalid gender. Must be Male, Female, or Other.");
        }
    }
    
    public static void validateRoomType(String roomType) throws HospitalManagementException {
        if (roomType == null ||
                !(roomType.equalsIgnoreCase("General") ||
                        roomType.equalsIgnoreCase("Private") ||
                        roomType.equalsIgnoreCase("Semi-Private"))) {
            throw new HospitalManagementException("Invalid room type. Must be General, Private, or ICU.");
        }
    }

    public static void validateFoodPreference(String food) throws HospitalManagementException {
        if (food == null ||
                !(food.equalsIgnoreCase("Yes") || food.equalsIgnoreCase("No"))) {
            throw new HospitalManagementException("Invalid food preference. Must be Yes or No.");
        }
    }
    
}
