package com.exception;

public class HospitalManagementException extends Exception {


	public HospitalManagementException(String message) {
		super(message);
	}

}