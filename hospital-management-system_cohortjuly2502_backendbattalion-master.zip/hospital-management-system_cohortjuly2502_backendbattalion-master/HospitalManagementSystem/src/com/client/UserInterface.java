package com.client;

import java.util.*;
import com.service.*;
import com.exception.*;
import com.model.Allocation;
import com.model.Appointment;
import com.model.Doctor;
import com.model.InPatient;
import com.model.OutPatient;
import com.model.Payment;



public class UserInterface
{
	public static void typeWriter(String text, int delay) {
        for (char c : text.toCharArray()) {
            System.out.print(c);
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    // 🔹 Method to show Apollo banner
    public static void showHospitalBanner() {
        System.out.println("\n\n");
        typeWriter("💙  APOLLO MULTI SPECIALITY HOSPITAL  💙\n", 30);
        typeWriter("       Your Health, Our Priority\n\n", 40);
    }
	@SuppressWarnings("resource")
	public static void main(String[] args) 
	{
		showHospitalBanner();
		
		Scanner sc=new Scanner(System.in);
       
      
          int choice;
    do { 
    	 System.out.println("============================================================");
    	    typeWriter("              👨‍⚕️  MAIN MENU  👩‍⚕️\n", 20);
    	    System.out.println("============================================================");
    	    typeWriter("  1️⃣  Doctor Management\n", 20);
    	    typeWriter("  2️⃣  Patient Management\n", 20);
    	    typeWriter("  3️⃣  Exit Application\n", 20);
    	    System.out.println("------------------------------------------------------------");
    	    typeWriter("👉 Enter your choice: ", 15);

    	    choice = Integer.parseInt(sc.nextLine());
    	    

      
	  switch(choice){
    	  
    	         case 1:
    	        	 int option;
    	        	 do {
    	        		 System.out.println("============================================================");
    	        		 typeWriter("           🩺  WELCOME TO DOCTOR MENU  🩺\n", 20);
    	        		 System.out.println("============================================================");
    	        		 typeWriter("  1️⃣  Add Doctor Details\n", 20);
    	        		 typeWriter("  2️⃣  Modify Doctor Details\n", 20);
    	        		 typeWriter("  3️⃣  Display Doctor Details\n", 20);
    	        		 typeWriter("  4️⃣  Exit to Main Menu\n", 20);
    	        		 System.out.println("------------------------------------------------------------");
    	        		 typeWriter("👉 Enter your option: ", 15);

    	        		 option = Integer.parseInt(sc.nextLine());
    	        		

    		        	   switch(option) {
    		        	   case 1:  

    		        		   System.out.println("---------------Add Details---------------");

    		        		   List<String> list = new ArrayList<>();
                               System.out.println("Enter The Number Of Details To Be Added:");
                               int count = Integer.parseInt(sc.nextLine());
                               System.out.println("Please Enter The Details In This Format [Name,Fees,Specialist,Date(dd-MM-yyyy),Time(hh:mm)]");
                              


                               try {
                                   for (int i = 0; i < count; i++) {
                                       System.out.println("Enter The Detail " + (i + 1) + ": ");
                                       String detail = sc.nextLine();
                                       list.add(detail);
                                   }
                                       int row=DoctorService.addDoctorToDB(list);
                                       if(row>0) {
                                    	   System.out.println(count+" Doctor Details Added");
                                       }
                                   
                               } catch (HospitalManagementException e) {
                                   System.out.println(e.getMessage());
                               }
                              
                               break;
    		        	   case 2:
    		        		   int opt;
    		        		   

//    		        		   option = Integer.parseInt(sc.nextLine());
    		        		
    		        		   	do {
    		        		   		System.out.println("============================================================");
    	    		        		   typeWriter("          ✏️  MODIFY DOCTOR DETAILS  ✏️\n", 20);
    	    		        		   System.out.println("============================================================");
    	    		        		   typeWriter("  1️⃣  Modify Appointment Date\n", 20);
    	    		        		   typeWriter("  2️⃣  Modify Consultation Fees\n", 20);
    	    		        		   typeWriter("  3️⃣  Back to Previous Menu\n", 20);
    	    		        		   System.out.println("------------------------------------------------------------");
    	    		        		   typeWriter("👉 Enter your option: ", 15);
    		        		   			opt=Integer.parseInt(sc.nextLine());
     		        			   switch(opt) {
     		        			   case 1:
     		        				    System.out.println("Enter The Doctor ID:");
     		        				    String doc = sc.nextLine();
     		        				    System.out.println("Enter The Date To Be Changed (dd-MM-yyyy):");
     		        				    String input = sc.nextLine();

     		        				    try {
     		        				        
     		        				       
     		        				        int rows = DoctorService.updateDoctorAvailableDate(doc,input);

     		        				        if (rows > 0) {
     		        				            System.out.println("Doctor Available Date updated successfully!");
     		        				        } 
     		        				 
     		        				    }catch (HospitalManagementException e) {
     		        				        System.out.println(e.getMessage());
     		        				    }
     		        				    break;
     		        			   case 2:
     		        				   
     		        				   System.out.println("Enter The Doctor ID:");
     		        				    String doc1 = sc.nextLine();

     		        				    System.out.println("Enter The Fees Amount:");
     		        				    double feeAmount = Double.parseDouble(sc.nextLine());
     		        				  

     		        				    try {
     		        				        int rows = DoctorService.updateDoctorFee(doc1,feeAmount);

     		        				        if (rows > 0) {
     		        				            System.out.println("Doctor Fee updated successfully!");
     		        				        } 

     		        				    } catch(HospitalManagementException e) {
     		        				        System.out.println(e.getMessage());
     		        				    } 
     		        				    break;
     		        			   case 3:
     		        				   System.out.println("Exiting to Previous Menu....");
     		        				   break;
     		        			   default:
     		        				   System.out.println("Invalid Option. Choose a valid Option!");
     		        				   break;
     		        			   }
    		        		   	}while(opt!=3);
    		        			   
    		        			   break;
    		        			  
    		        			   
    		        	   case 3:
    		        		   System.out.println("---------------Doctor Details---------------");

    		        		   System.out.print("Enter the Doctor ID: ");
    		        		   String doc = sc.nextLine();

    		        		   try {
    		        		       Doctor d = DoctorService.retrieveDoctorDetails(doc);

    		        		       if (d != null) {
    		        		           System.out.println("\n✅ Doctor Details Retrieved Successfully!");
    		        		           System.out.println("-------------------------------------------");
    		        		           System.out.println("Doctor ID        : " + d.getDoctorId());
    		        		           System.out.println("Doctor Name      : " + d.getDoctorName());
    		        		           System.out.println("Specialization   : " + d.getSpecialization());
    		        		           System.out.println("Consultation Fee : ₹" + d.getDoctorFee());
    		        		           System.out.println("Available Date   : " + d.getAvailableDate());
    		        		           System.out.println("Available Time   : " + d.getAvailableTime());
    		        		           System.out.println("-------------------------------------------");
    		        		       } 
    		        		       else {
    		        		           System.out.println("\n⚠ No doctor found with the given ID!");
    		        		       }

    		        		   } catch (HospitalManagementException e) {
    		        		       System.out.println("\n⚠ Error: " + e.getMessage());
    		        		   } catch (Exception e) {
    		        		       System.out.println("\n⚠ Unexpected error occurred: " + e.getMessage());
    		        		   }

    		        		   break;

    		        	   case 4:
    		        		   System.out.println("Exiting To The Main Menu");
    		        		   break;
    		        			   }
    		        			   
    	        	 }while(option!=4);
    	        	 break;
    		        	
    		        		   
    	         case 2:
    	        	 int patientOption;
    	        	 do {
    	        		 System.out.println("============================================================");
    	        		 typeWriter("      💚  WELCOME TO PATIENT MENU  💚\n", 20);
    	        		 System.out.println("============================================================");
    	        		 typeWriter("  1️⃣  Add Patient Details\n", 20);
    	        		 typeWriter("  2️⃣  Modify Patient Details\n", 20);
    	        		 typeWriter("  3️⃣  Appointment for Out-Patient\n", 20);
    	        		 typeWriter("  4️⃣  Allocation for In-Patient\n", 20);
    	        		 typeWriter("  5️⃣  Payment Section\n", 20);
    	        		 typeWriter("  6️⃣  Display Patient Details\n", 20);
    	        		 typeWriter("  7️⃣  Delete Patient Record\n", 20);
    	        		 typeWriter("  8️⃣  Exit to Main Menu\n", 20);
    	        		 System.out.println("------------------------------------------------------------");
    	        		 typeWriter("👉 Enter Your Option: ", 15);

//    	        		 option = Integer.parseInt(sc.nextLine());
    	        		

    	        	 patientOption=Integer.parseInt(sc.nextLine());
    	        	
    	        	 switch(patientOption) {
    	        	 case 1:
    	        		  System.out.println("---------------Add Details---------------");
    	        		  System.out.println("1.InPatient Details To Be Added");
    	        		  System.out.println("2.OutPatient Details To Be Added");
    	        		  System.out.println("Enter your Option: ");
    	        		  int addChoice=Integer.parseInt(sc.nextLine());;
    	        		  switch(addChoice) {
    	        		  case 1:
		        		   List<String> ipList = new ArrayList<>();
                          System.out.println("Enter The Number Of  InPatient Details To Be Added:");
                          int ipcount = Integer.parseInt(sc.nextLine());
                     
                          System.out.println("Enter the details in this format [name,phno,age,gender,medical_history,preff_specialist,medicine_fee,patient_type,admission_fee,treatment,wantfood]");
                          try {
                              for (int i = 0; i < ipcount; i++) {
                                  System.out.println("Enter The Detail " + (i + 1) + ": ");
                                  String detail = sc.nextLine();
                                  ipList.add(detail);
                              }
                                  int row=InPatientService.addInPatientListToDB(ipList);
                                  if(row>0) {
                               	   System.out.println(ipcount+" InPatient Details Added");
                                  }

                          } catch (HospitalManagementException e) {
	     				        System.out.println(e.getMessage());
	     				    }
                          break;
                          case 2:

                          List<String> opList = new ArrayList<>();
                          System.out.println("Enter The Number Of OutPatient Details To Be Added:");
                          int opcount = Integer.parseInt(sc.nextLine());;
                          System.out.println("Enter the details in this format [name,phNo,age,gender,medicalHistory,preff_specialist,medicineFee,patientType,reg_fees]");

                          try {
                              for (int i = 0; i < opcount; i++) {
                                  System.out.println("Enter The Detail " + (i + 1) + ": ");
                                  String detail = sc.nextLine();
                                  opList.add(detail);     
                              }
                              int row=OutPatientService.addOutPatientListToDB(opList);
                              if(row>0) {
                           	   System.out.println(opcount+" OutPatient Details Added");
                              }
                          }catch (HospitalManagementException e) {
	     				        System.out.println(e.getMessage());
	     				    }
                          break;
    	        		  }
                          break;
    	        	 case 2:
    	        		 System.out.println("---------------Modify Patient Details---------------");
    	        		 System.out.println("Enter The Patient ID:");
    	        		 String patientId=sc.nextLine();
    	        		 if(patientId.startsWith("IP")) {
    	        			int choose;
    	        			 do {
    	        				 System.out.println("============================================================");
    	        				 typeWriter("      ✏️  MODIFY PATIENT DETAILS  ✏️\n", 20);
    	        				 System.out.println("============================================================");
    	        				 typeWriter("  1️⃣  Update Phone Number\n", 20);
    	        				 typeWriter("  2️⃣  Change Want Food\n", 20);
    	        				 typeWriter("  3️⃣  Change Room Type\n", 20);
    	        				 typeWriter("  4️⃣  Back to Previous Menu\n", 20);
    	        				 System.out.println("------------------------------------------------------------");
    	        				 typeWriter("👉 Enter Your Option: ", 15);

//    	        				 option = Integer.parseInt(sc.nextLine());
    	        				

    	        			 choose=Integer.parseInt(sc.nextLine());
    	        
    	        			 switch(choose){
    	        			 case 1:
    	        			 System.out.println("Enter The Phone Number To Be Changed");
    	        			 String inPhNo=sc.nextLine();
    	        			 try {
    	     				        int rows = InPatientService.updateInPatientPhoneNumber(patientId,inPhNo);    	     				       
    	     				        if (rows >0) {
    	     				            System.out.println("Patient Phone Number updated successfully");
    	     				        } 
    	     				    }catch (HospitalManagementException e) {
    	     				        System.out.println(e.getMessage());
    	     				    }
    	        			 break;
    	        			 case 2:
    	        	         
    	        			 System.out.println("Enter whether you want food (yes/no)");
    	        			 String foodType=sc.nextLine();
    	        			 try {
    	     				        int rows = InPatientService.updateInPatientFoodPreference(patientId,foodType); 	     				       

    	     				        if (rows >0) {
    	     				            System.out.println("Patient Food Preference updated successfully!");
    	     				        } 
    	     				    }catch (HospitalManagementException e) {
    	     				        System.out.println(e.getMessage());
    	     				    }
    	        			 break;
    	        			 case 3:
    	        				 System.out.println("Enter The Room Type You Want (General/Semi-Private/Private)");
        	        			 String roomType=sc.nextLine();
        	        			 try {
     	     				        int rows = InPatientService.updateInPatientRoomType(patientId,roomType); 	     				       

     	     				        if (rows >0) {
     	     				            System.out.println("Patient Room Type updated successfully!");
     	     				        } 
     	     				    }catch (HospitalManagementException e) {
     	     				        System.out.println(e.getMessage());
     	     				    }
        	        			 break;
    	        			 case 4:
    	        				 System.out.println("Exiting to Patient Menu");
    	        				 break;
    	        			 default:
    	        	    		 System.out.println("Invalid Choice! Please Try Again With Correct option");	
    	        	    		 break;
    	        			 }
    	        		
    	        			 }while(choose!=4);
    	        			
    	        		  
    	        	 }else if(patientId.startsWith("OP")) {
    	        		 int choose;
	        			 do {
	        				 System.out.println("============================================================");
	        				 typeWriter("      ✏️  MODIFY PATIENT DETAILS  ✏️\n", 20);
	        				 System.out.println("============================================================");
	        				 typeWriter("  1️⃣  Update Phone Number\n", 20);
	        				 typeWriter("  2️⃣  Back to Previous Menu\n", 20);
	        				 System.out.println("------------------------------------------------------------");
	        				 typeWriter("👉 Enter Your Option: ", 15);

//	        				 option = Integer.parseInt(sc.nextLine());
	        				

	        			 choose=Integer.parseInt(sc.nextLine());
	        
	        			 switch(choose){
	        			 case 1:
    	        			 System.out.println("Enter The Phone Number To Be Changed");
    	        			 String opPhNo=sc.nextLine();
    	        			 try {
 	     				        int rows = OutPatientService.updateOutPatientPhoneNumber(patientId,opPhNo);    	     				       
 	     				        if (rows >0) {
 	     				            System.out.println("Patient Phone Number updated successfully!");
 	     				        }
 	     				 
 	     				    }catch (HospitalManagementException e) {
 	     				        System.out.println(e.getMessage());
 	     				    }
    	        			 
    	        			break;
	        			 case 2:
	        				 System.out.println("Exiting to Previous Menu");
	        				 break;
	        			default:
	        				System.out.println("Invalid Choice! Please Try Again With Correct option");
	        				break;
	        			 		}
	        		 		}while(choose!=2);
	        			 }
	        			 else {
    	        			 System.out.println("Invalid ID. Patient ID should starts with IPXXXX or OPXXXX");
    	        		 }
    	        			 break;
    	        	 case 3:
    	        		 System.out.println("---------------Appointment For OutPatient Details---------------");
    	        		 System.out.println("1.Book Appointment");
    	        		 System.out.println("2.Display Details");
    	        		 System.out.println("3.Delete Details");
    	        		 System.out.println("4.Back to Previous Menu");
    	        		 System.out.println("Enter your choice: ");
    	        		 int appointment=Integer.parseInt(sc.nextLine());;
    	        		 switch(appointment) {
    	        		 case 1:
    	        			 System.out.println("---------------Book Appointment---------------");
    	        			 System.out.println("Enter The Patient ID");
    	        			 String patientIdAppointment=sc.nextLine();
    	        			 System.out.println("What Type Of Appointment Do you Want?");
    	        			 String mode=sc.nextLine();
    	        			 try {
    	        				Appointment ap=AppointmentService.bookAppointment(patientIdAppointment,mode);
    	        			
		     				    System.out.println("Appointment Booked successfully!");
		     				   System.out.println("------------------------------------------------------------");
      			             System.out.println("Appointment ID      : " + ap.getAppointmentId());
      			             System.out.println("Patient ID          : " + ap.getPatientId());
      			             System.out.println("Doctor ID           : " + ap.getDoctorId());
      			             System.out.println("Doctor Name         : " + ap.getDoctorName());
      			             System.out.println("Specialization      : " + ap.getSpecialization());
      			             System.out.println("Appointment Date    : " + ap.getAppointmentDate());
      			             System.out.println("Appointment Time    : " + ap.getAppointmentTime());
      			             System.out.println("Mode of Appointment : " + ap.getModeOfAppointment());
      			             System.out.println("------------------------------------------------------------");
	     				    }catch (HospitalManagementException e) {
	     				        System.out.println(e.getMessage());
	     				    }
    	        			 break;
    	        		 case 2:
    	        			 System.out.println("---------------Display Appointment Details---------------");
    	        			 System.out.print("Enter the Patient ID: ");
    	        			 String patientIdAppointmentDisplay = sc.nextLine();

    	        			 try {
    	        			     List<Appointment> appointmentList = AppointmentService.retrieveAppointmentDetails(patientIdAppointmentDisplay);

    	        			     if (appointmentList == null || appointmentList.isEmpty()) {
    	        			         System.out.println("\n⚠ No Appointment Records Found for Patient ID: " + patientIdAppointmentDisplay);
    	        			     } else {
    	        			         System.out.println("\n✅ Appointment Details Retrieved Successfully!");
    	        			         

    	        			         for (Appointment ap : appointmentList) {
    	        			        	 System.out.println("------------------------------------------------------------");
    	        			             System.out.println("Appointment ID      : " + ap.getAppointmentId());
    	        			             System.out.println("Patient ID          : " + ap.getPatientId());
    	        			             System.out.println("Doctor ID           : " + ap.getDoctorId());
    	        			             System.out.println("Doctor Name         : " + ap.getDoctorName());
    	        			             System.out.println("Specialization      : " + ap.getSpecialization());
    	        			             System.out.println("Appointment Date    : " + ap.getAppointmentDate());
    	        			             System.out.println("Appointment Time    : " + ap.getAppointmentTime());
    	        			             System.out.println("Mode of Appointment : " + ap.getModeOfAppointment());
    	        			             System.out.println("------------------------------------------------------------");
    	        			         }
    	        			     }
    	        			 } catch (HospitalManagementException e) {
    	        			     System.out.println("\n⚠ Error: " + e.getMessage());
    	        			 } catch (Exception e) {
    	        			     System.out.println("\n⚠ Unexpected error occurred: " + e.getMessage());
    	        			 }

    	        			 break;

    	    	        			 
    	        		 case 3:
    	        			 System.out.println("---------------Delete Details---------------");
    	        			 System.out.println("Enter The Patient ID");
    	        			 String deletePatientId=sc.nextLine();
    	        			 try {
    	    	        			int row=AppointmentService.deleteAppointmentDetailsFromDB(deletePatientId);
    		     				    if(row>0) {
    		     				    	System.out.println("Appointment Deleted Successfully!");
    		     				    }
    	        			 }catch (HospitalManagementException e) {
		     				        System.out.println(e.getMessage());
		     				    }
	        			 	break; 
    	        		 case 4:
	        				 System.out.println("Exiting to Previous Menu");
	        				 break;
	        			 default:
	        	    		 System.out.println("Invalid Choice! Please Try Again With Correct option");	
	        	    		 break;
    	        		 }
                          break;
    	        	 case 4:
    	        		 int choose;
    	        		 do {
        	        		 System.out.println("---------------Allocation Details---------------");
        	        		 System.out.println("1.Book Allocation");
        	        		 System.out.println("2.Discharge");
        	        		 System.out.println("3.Display");
        	        		 System.out.println("4.Delete");
        	        		 System.out.println("5.Back to Previous Menu");
        	        		 System.out.println("Enter your choice: ");
        	        		 choose=Integer.parseInt(sc.nextLine());;
        	        		 switch(choose) {
        	        		 case 1:
        	        			 System.out.println("---------------Allocation Book---------------");
        	        			 System.out.println("Enter The PatientID");
        	        			 String allocationPatientId=sc.nextLine();
        	        			 System.out.println("Enter The Admission Date");
        	        			 String admissionDate=sc.nextLine();
        	        			 System.out.println("Enter The Room Type You Want (General/Semi-Private/Private)");
        	        			 String roomType=sc.nextLine();
        	        			 try {
    								int row=AllocationService.bookAllocation(allocationPatientId, admissionDate, roomType);
    								
    								if(row>0) {
    									System.out.println("Room allocated successfully!");
    									Allocation al=AllocationService.retrieveAllocationDetails(allocationPatientId);
    	   	        			         System.out.println("------------------------------------------------------------");
    	   	        			         System.out.println("Allocation ID        : " + al.getAllocationId());
    	   	        			         System.out.println("Patient ID           : " + al.getPatientId());
    	   	        			         System.out.println("Room Number          : " + al.getRoomNumber());
    	   	        			         System.out.println("No. of Days Admitted : " + al.getNoOfDaysAdmitted());
    	   	        			         System.out.println("Admission Date       : " + al.getAdmissionDate());
    	   	        			         System.out.println("Discharge Date       : " + al.getDischargeDate());
    	   	        			         System.out.println("Treatment            : " + al.getTreatment());
    	   	        			         System.out.println("Room Type            : " + al.getRoomType());
    	   	        			         System.out.println("Want Food            : " + al.getWantFood());
    	   	        			         System.out.println("------------------------------------------------------------");							
    								}
        	        			 } catch (HospitalManagementException e) {
    								System.out.println(e.getMessage());
    							}
        	        			 
        	        			 break;
        	        		 case 2:
        	        			 System.out.println("---------------Discharge---------------");
        	        			 System.out.println("Enter The Patient ID");
        	        			 String pId=sc.nextLine();
        	        			 System.out.println("Enter the Discharge Date:");
        	        			 String dischargeDate=sc.nextLine();
        	        			 
        	        			 int row;
    							try {
    								row = AllocationService.updateDischargeDate(pId, dischargeDate);
    								if(row>0) {
    	    	        				 System.out.println("Discharge date updated successfully");
    	    	        			 }
    							} catch (HospitalManagementException e) {
    								System.out.println(e.getMessage());
    							}
        	        			 
        	        			 break;
        	        		 case 3:
        	        			 System.out.println("---------------Display Allocation Details---------------");
        	        			 System.out.print("Enter the Patient ID: ");
        	        			 String patientAllocationDisplayID = sc.nextLine();

        	        			 try {
        	        			     Allocation al = AllocationService.retrieveAllocationDetails(patientAllocationDisplayID);

        	        			     if (al == null) {
        	        			         System.out.println("\n⚠ No Allocation Records Found for Patient ID: " + patientAllocationDisplayID);
        	        			     } else {
        	        			         System.out.println("\n✅ Allocation Details Retrieved Successfully!");
        	        			         System.out.println("------------------------------------------------------------");
        	        			         System.out.println("Allocation ID        : " + al.getAllocationId());
        	        			         System.out.println("Patient ID           : " + al.getPatientId());
        	        			         System.out.println("Room Number          : " + al.getRoomNumber());
        	        			         System.out.println("No. of Days Admitted : " + al.getNoOfDaysAdmitted());
        	        			         System.out.println("Admission Date       : " + al.getAdmissionDate());
        	        			         System.out.println("Discharge Date       : " + al.getDischargeDate());
        	        			         System.out.println("Treatment            : " + al.getTreatment());
        	        			         System.out.println("Room Type            : " + al.getRoomType());
        	        			         System.out.println("Want Food            : " + al.getWantFood());
        	        			         System.out.println("------------------------------------------------------------");
        	        			     }
        	        			 } catch (HospitalManagementException e) {
        	        			     System.out.println("\n⚠ Error: " + e.getMessage());
        	        			 } catch (Exception e) {
        	        			     System.out.println("\n⚠ Unexpected error occurred: " + e.getMessage());
        	        			 }

        	        			 break;

        	        		 case 4:
        	        			 System.out.println("--------------Delete---------------");
        	        			 System.out.println("Enter The Patient ID");
        	        			 String patientAllocationDeleteID=sc.nextLine();
        	        			 try {
     								int rows=AllocationService.deleteAllocationDetails(patientAllocationDeleteID);
     								if(rows>0) {
     									System.out.println("Allocation Details deleted successfully!");
     								}
         	        			 } catch (HospitalManagementException e) {
     								System.out.println(e.getMessage());
     							}
        	        			 break;
        	        		 case 5:
    	        				 System.out.println("Exiting to Previous Menu");
    	        				 break;
    	        			 default:
    	        	    		 System.out.println("Invalid Choice! Please Try Again With Correct option");	
    	        	    		 break;
        	        		 }
    	        		 }while(choose!=5);

    	        		 break;
    	        		 
    	        	 case 5:
    	        		 try {
 	        	            System.out.println("---------------Payment---------------");
 	        	            System.out.println("---------------Calculate Bill---------------");

 	        	            System.out.print("Enter the Patient ID: ");
 	        	            String patientId1 = sc.nextLine();

 	        	            // Step 1: Calculate bill amount
 	        	            double amount = PaymentService.calculateBill(patientId1);
 	        	            System.out.println("\nCalculated Bill Amount: ₹" + amount);

 	        	            // Step 2: Ask if user wants to pay
 	        	            System.out.print("\nDo you want to proceed with payment? (Yes/No): ");
 	        	            String payChoice = sc.nextLine();

 	        	            if (payChoice.equalsIgnoreCase("Yes")) {
 	        	                System.out.print("Enter the Mode of Payment (Cash / Card / UPI): ");
 	        	                String mode = sc.nextLine();

 	        	                // Step 3: Generate payment details
 	        	                int paymentDone = PaymentService.generateBill(patientId1, amount, mode);
 	        	               if(paymentDone>0) {
	        	                	List<Payment> paymentList=PaymentService.retrievePaymentDetailsByPatientId(patientId1);
	        	                	System.out.println("\n✅ Payment Successful!");
	        	                	for(Payment payment:paymentList) {   
       	        	                System.out.println("----------------------------------------");
       	        	                System.out.println("Payment ID       : " + payment.getPaymentId());
       	        	                System.out.println("Patient ID       : " + payment.getPatientId());
       	        	                System.out.println("Patient Name     : " + payment.getPatientName());
       	        	                System.out.println("Patient Type     : " + payment.getPatientType());
       	        	                System.out.println("Payment Date     : " + payment.getPaymentDate());
       	        	                System.out.println("Payment Mode     : " + payment.getModeOfPayment());
       	        	                System.out.println("Amount Paid (₹)  : " + payment.getBillAmount());
       	        	                System.out.println("----------------------------------------");
	        	                	}
	        	                }   
	        	            } 
	        	            else {
	        	                System.out.println("\nPayment Cancelled.");
	        	            }

	        	        } catch (HospitalManagementException e) {
	        	            System.out.println("\n⚠ Error: " + e.getMessage());
	        	        } catch (Exception e) {
	        	            System.out.println("\n⚠ Unexpected error occurred: " + e.getMessage());
	        	        }

	        	    
                        break;
                          
    	        	 case 6:
    	        		 System.out.println("---------------Display Patient Details---------------");
    	        		 System.out.println("Which Patient Details Do You Want To View?");
    	        		 System.out.println("1. In-Patient Details");
    	        		 System.out.println("2. Out-Patient Details");
    	        		 System.out.print("Enter your choice: ");

    	        		 int detailsOption = Integer.parseInt(sc.nextLine());

    	        		 switch (detailsOption) {
    	        		     case 1:
    	        		         System.out.print("Enter the In-Patient ID: ");
    	        		         String patientIn = sc.nextLine();
    	        		         try {
    	        		             InPatient ip = InPatientService.retrieveInPatientDetails(patientIn);
    	        		             
    	        		             if (ip != null) {
    	        		                 System.out.println("\n✅ In-Patient Details Retrieved Successfully!");
    	        		                 System.out.println("--------------------------------------------------");
    	        		                 System.out.println("Patient ID          : " + ip.getPatientId());
    	        		                 System.out.println("Patient Name        : " + ip.getPatientName());
    	        		                 System.out.println("Phone Number        : " + ip.getPhoneNumber());
    	        		                 System.out.println("Age                 : " + ip.getAge());
    	        		                 System.out.println("Gender              : " + ip.getGender());
    	        		                 System.out.println("Medical History     : " + ip.getMedicalHistory());
    	        		                 System.out.println("Preferred Specialist: " + ip.getPreferredSpecialist());
    	        		                 System.out.println("Medicine Fee (₹)    : " + ip.getMedicineFee());
    	        		                 System.out.println("Patient Type        : " + ip.getPatientType());
    	        		                 System.out.println("Admission Fee (₹)   : " + ip.getAdmissionFees());
    	        		                 System.out.println("Treatment           : " + ip.getTreatment());
    	        		                 System.out.println("Room Type           : " + ip.getRoomType());
    	        		                 System.out.println("Wants Food          : " + ip.getWantFood());
    	        		                 System.out.println("--------------------------------------------------");
    	        		             } else {
    	        		                 System.out.println("\n⚠ No In-Patient found with the given ID!");
    	        		             }

    	        		         } catch (HospitalManagementException e) {
    	        		             System.out.println("\n⚠ Error: " + e.getMessage());
    	        		         } catch (Exception e) {
    	        		             System.out.println("\n⚠ Unexpected error: " + e.getMessage());
    	        		         }
    	        		         break;
    	        			 
    	        		 case 2:
    	        			 System.out.print("Enter the Out-Patient ID: ");
    	        		        String patientOp = sc.nextLine();
    	        		        try {
    	        		            OutPatient op = OutPatientService.retrieveOutPatientDetails(patientOp);
    	        		            
    	        		            if (op != null) {
    	        		                System.out.println("\n✅ Out-Patient Details Retrieved Successfully!");
    	        		                System.out.println("--------------------------------------------------");
    	        		                System.out.println("Patient ID          : " + op.getPatientId());
    	        		                System.out.println("Patient Name        : " + op.getPatientName());
    	        		                System.out.println("Phone Number        : " + op.getPhoneNumber());
    	        		                System.out.println("Age                 : " + op.getAge());
    	        		                System.out.println("Gender              : " + op.getGender());
    	        		                System.out.println("Medical History     : " + op.getMedicalHistory());
    	        		                System.out.println("Preferred Specialist: " + op.getPreferredSpecialist());
    	        		                System.out.println("Medicine Fee (₹)    : " + op.getMedicineFee());
    	        		                System.out.println("Patient Type        : " + op.getPatientType());
    	        		                System.out.println("Registration Fee (₹): " + op.getRegistrationFees());
    	        		                System.out.println("--------------------------------------------------");
    	        		            } else {
    	        		                System.out.println("\n⚠ No Out-Patient found with the given ID!");
    	        		            }

    	        		        } catch (HospitalManagementException e) {
    	        		            System.out.println("\n⚠ Error: " + e.getMessage());
    	        		        } catch (Exception e) {
    	        		            System.out.println("\n⚠ Unexpected error: " + e.getMessage());
    	        		        }
    	        		        break;

    	        		    default:
    	        		        System.out.println("\n⚠ Invalid choice! Please select 1 or 2.");
    	        		        break;
    	        		}

    	        		break;
    	        	 case 7:
    	        		 int deleteOption;
    	        		 do {
    	        		 System.out.println("---------------Delete Details---------------");
    	        		 System.out.println("Which Patient Do You Want To Delete Details");
    	        		 System.out.println("1.InPatient Details");
    	        		 System.out.println("2.OutPatient Details");
    	        		 System.out.println("3.Back to Previous Menu");
    	        		 System.out.println("Enter the choice: ");
    	        		 deleteOption=Integer.parseInt(sc.nextLine());
    	        		 switch(deleteOption) {
    	        		 case 1:
    	        			 System.out.println("Enter The Patient ID");
    	        			 String inPatient=sc.nextLine();
    	        			 try {
    	        				 int deleteRow=InPatientService.deleteInPatientDetails(inPatient);
    	        				 if(deleteRow>0) {
    	        					 System.out.println("Patient Details Deleted Successfully!");
    	        				 }
 							} catch (HospitalManagementException e) {
 								// TODO Auto-generated catch block
 								System.out.println(e.getMessage());
 							}
    	        			 break;
    	        		 case 2:
    	        			 
    	        			 System.out.println("Enter The Patient ID");
    	        			 String opPatient=sc.nextLine();
    	        			 try {
    	        				 int deleteRow=OutPatientService.deleteOutPatientDetails(opPatient);
    	        				 if(deleteRow>0) {
    	        					 System.out.println("Patient Details Deleted Successfully!");
    	        				 }
 							} catch (HospitalManagementException e) {
 								// TODO Auto-generated catch block
 								System.out.println(e.getMessage());
 							}
    	        			 break;
    	        		 case 3:
    	        			 System.out.println("Exiting to Previous Menu");
    	        			 break;
    	        		 default:
    	        			 System.out.println("Invalid Option. Enter correct choice.");
    	        			 break;
    	        		 }
    	        		 }while(deleteOption!=3);
    	        		 break;
    	        	 case 8:
    	        		 System.out.println("Exiting To The Menu");
    	        		 break;
    	        		 
    	        	 }
    	        	
    	        	 }while(patientOption!=8);
    		           break;
    	         case 3:
    	        	 System.out.println("Take Care Of Your Health.Stay Healthy!");
    	        	 break;
    	         default:
    	    		 System.out.println("Invalid Choice!Please Try Again With Correct option");	
    	    		 break;
    	        	 }    	     	 
	
    	  
	
    }while(choice!=3);


	
}
}