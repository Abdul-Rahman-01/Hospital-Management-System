package com.service;

import java.util.*;
import java.time.*;
import com.exception.HospitalManagementException;
import com.model.*;
import com.util.*;
import com.management.*;

public class DoctorService {


	private final static List<Doctor> doctorObjectList=new ArrayList<Doctor>();
	

	
	public static List<Doctor> addDoctorDetails(List<String> doctorDetails) throws HospitalManagementException{
		if(doctorDetails.isEmpty()) {
			throw new HospitalManagementException("Input record is empty");
		}
		
		int docIdFromDB=ApplicationUtil.generateDoctorId();
		for(String detail:doctorDetails) {
			List<String> parsedDetails=ApplicationUtil.extractDetails(detail);
			if(parsedDetails.size()<5) {
				throw new HospitalManagementException("Doctor record must contains 5 fields");
			}
			
			//input name,fees,specialization,availableDate,time
			docIdFromDB++;
			String doctorId="DOC"+docIdFromDB;
			String doctorName=parsedDetails.get(0);
			double doctorFees;
			try {
				doctorFees=Double.parseDouble(parsedDetails.get(1));
			}
			catch(NumberFormatException e) {
				throw new HospitalManagementException("Invalid fee input given");
			}
			String specialization=parsedDetails.get(2);
			LocalDate availableDate;
			LocalTime availableTime;
			try {
				availableDate=ApplicationUtil.parseLocalDate(parsedDetails.get(3));
				availableTime=ApplicationUtil.parseLocalTime(parsedDetails.get(4));
			}
			catch(Exception e) {
				throw new HospitalManagementException("Invalid Date/Time");
			}
			Doctor doc=new Doctor(doctorId,doctorName,doctorFees,specialization,availableDate,availableTime);
			doctorObjectList.add(doc);
		}
		
		
		return doctorObjectList;
	}
	
	public static int addDoctorToDB(List<String> doctorRecord) throws HospitalManagementException{
		List<Doctor> doctorObjList=addDoctorDetails(doctorRecord);
		
		int rows=DoctorManagement.insertDoctor(doctorObjList);
		if(rows<=0) {
			throw new HospitalManagementException("Failed to insert doctor details");
		}
		return rows;
	}
	
	public static int updateDoctorFee(String doctorId,double doctorFee) throws HospitalManagementException {
		ApplicationUtil.validateDoctorId(doctorId);
		ApplicationUtil.validateFee(doctorFee);
		
		int rows=DoctorManagement.updateDoctorFee(doctorId,doctorFee);
		if(rows<=0) {
			throw new HospitalManagementException("Failed to update doctor fees:"+doctorId);
		}
		return rows;
	}
	
	public static int updateDoctorAvailableDate(String doctorId,String availableDate) throws HospitalManagementException {
		ApplicationUtil.validateDoctorId(doctorId);
		LocalDate updatedDate=ApplicationUtil.parseLocalDate(availableDate);
		
		int rows=DoctorManagement.updateDoctorAvailableDate(doctorId,updatedDate);
		if(rows<=0) {
			throw new HospitalManagementException("Failed to update doctor available Date:"+doctorId);
		}
		return rows;
	}
	
	public static Doctor retrieveDoctorDetails(String doctorId) throws HospitalManagementException{
		ApplicationUtil.validateDoctorId(doctorId);
		Doctor doc=DoctorManagement.retrieveDoctorDetailsFromDB(doctorId);
		if(doc==null) {
			throw new HospitalManagementException("Doctor Details not found for ID:"+doctorId);
		}
		return doc;
	}
	
	public static List<Doctor> retrieveDoctorDetailsBySpecialization(String specialization) throws HospitalManagementException{
		
		List<Doctor> docDetailsBySpecialization=DoctorManagement.retrieveDoctorDetailsBySpecializationFromDB(specialization);
		
		
		if(docDetailsBySpecialization.isEmpty()) {
			throw new HospitalManagementException("No doctor found for specialization - "+specialization);
		}
		return docDetailsBySpecialization;
	}
	
//	public static void main (String args[]) throws SQLException {
//		//DoctorService doc=new DoctorService();
//		List<String> details=new ArrayList<String>();
//		Scanner sc=new Scanner(System.in);
//		System.out.println("ENter details: ");
//		//input name,fees,specialization,availableDate,time
//		String detail=sc.nextLine();
//		details.add(detail);
//		try {
//			int i=DoctorService.addDoctorToDB(details);
//			System.out.println(i);
//			
//			System.out.println("Enter doctor id and fees , seperated");
//			String idFee=sc.nextLine();
//			
//			if(DoctorService.updateDoctorFee(idFee.split(",")[0],Double.parseDouble(idFee.split(",")[1]))>0) {
//				System.out.println("fee updated");
//			}
//			
//			System.out.println("Enter doctor id and date , seperated");
//			String idDate=sc.nextLine();
//			
//			if(DoctorService.updateDoctorAvailableDate(idDate.split(",")[0],idDate.split(",")[1])>0) {
//				System.out.println("date updated");
//			}
//			
//			System.out.println("Enter to retrieve : ");
//			String id=sc.next();
//			Doctor doc1=DoctorService.retrieveDoctorDetails(id);
//			System.out.println(doc1);
//			
//		} catch (HospitalManagementException e) {
//			// TODO Auto-generated catch block
//			System.out.println(e.getMessage());
//		}
//	}
	
}
