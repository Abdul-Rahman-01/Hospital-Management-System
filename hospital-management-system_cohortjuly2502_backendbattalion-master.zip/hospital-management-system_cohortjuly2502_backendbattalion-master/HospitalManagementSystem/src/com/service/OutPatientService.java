package com.service;

import java.util.ArrayList;
import java.util.List;

import com.model.*;
import com.util.ApplicationUtil;
import com.management.OutPatientManagement;
import com.exception.HospitalManagementException;

public class OutPatientService {

	    //Build OutPatient List from Input
	    public static List<OutPatient> buildOutPatientList(List<String> recordList) throws HospitalManagementException {
	        List<OutPatient> opPatientList = new ArrayList<>();

	        // PATIENT_ID -generate
	        //PATIENT_NAME PHONE_NUMBER   AGE GENDER MEDICAL_HISTORY PREFFERED_SPECIALIST 
	        
	        //MEDICINE_FEE PATIENT_TYPE  REGISTRATION_FEES 
	        
	        int opIdFromDB=ApplicationUtil.generateOutPatientId();
	        for (String record : recordList) {
	            List<String> parsedDetail=ApplicationUtil.extractDetails(record);
	            
	            if(parsedDetail.size()<9) {
	            	throw new HospitalManagementException("Out Patient Details must contain 9 records");
	            }
	            
	            opIdFromDB++;
	            String patientId="OP"+opIdFromDB;
	            
	            String patientName=parsedDetail.get(0);
	            
	            ApplicationUtil.validatePhoneNumber(parsedDetail.get(1));
	            long patientPhNo=Long.parseLong(parsedDetail.get(1));
	            
	            int age=Integer.parseInt(parsedDetail.get(2));
	            ApplicationUtil.validateAge(age);
	            
	            String gender=parsedDetail.get(3);
	            ApplicationUtil.validateGender(gender);
	            		
	            String medicalHistory=parsedDetail.get(4);
	            
	            String preferredSpecialist=parsedDetail.get(5);
	            
	            double medicineFee=Double.parseDouble(parsedDetail.get(6));
	            ApplicationUtil.validateFee(medicineFee);
	            
	            
	            String patientType=parsedDetail.get(7);
	            
	            double registrationFee=Double.parseDouble(parsedDetail.get(8));
	            ApplicationUtil.validateFee(registrationFee);
	               
	            
	            OutPatient op=new OutPatient(patientId, patientName, patientPhNo, age, gender, medicalHistory, preferredSpecialist, medicineFee, patientType, registrationFee);

	            opPatientList.add(op);
	        }
	        return opPatientList;
	    }

	    //Add OutPatient List to Database
	    public static int addOutPatientListToDB(List<String> recordList) throws HospitalManagementException{
	        List<OutPatient> opPatientList = buildOutPatientList(recordList);
	        int rows=OutPatientManagement.insertOutPatientListDB(opPatientList);
	        if(rows<=0) {
	        	throw new HospitalManagementException("Failed to insert Out Patient details");
	        }
	        return rows;
	    }
	    
	    //Update OutPatient Phone Number
	    public static int updateOutPatientPhoneNumber(String patientId, String newPhoneNumber)
	            throws HospitalManagementException {
	    	
	    	ApplicationUtil.validateOutPatientId(patientId);
	    	ApplicationUtil.validatePhoneNumber(newPhoneNumber);
	    	
	    	int row=OutPatientManagement.updateOutPatientPhoneNumberDB(patientId, Long.parseLong(newPhoneNumber));
	    	if(row<=0) {
	    		throw new HospitalManagementException("Patient Phone Number not Updated");
	    	}
	        return row;
	    }


	    //Retrieve OutPatient Details
	    public static OutPatient retrieveOutPatientDetails(String patientId)
	            throws HospitalManagementException {
	    	
	    	ApplicationUtil.validateOutPatientId(patientId);
	    	
	    	OutPatient op=OutPatientManagement.retrieveOutPatientDetailsDB(patientId);
	    	if(op==null) {
	    		throw new HospitalManagementException("Patient not Found");
	    	}
	        return op;
	    }

	    //Delete InPatient Details
	    public static int deleteOutPatientDetails(String patientId)
	            throws HospitalManagementException {
	    	
	    	ApplicationUtil.validateOutPatientId(patientId);
	    	
	    	int row=OutPatientManagement.deleteOutPatientDetailsFromDB(patientId);
	    	
	    	if(row<=0) {
	    		throw new HospitalManagementException("Patient Id not deleted");
	    	}
	        return row;
	    }
    }