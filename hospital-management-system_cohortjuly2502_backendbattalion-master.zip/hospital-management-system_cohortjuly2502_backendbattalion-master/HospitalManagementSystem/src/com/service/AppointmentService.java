package com.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.model.Appointment;
import com.model.Doctor;
import com.model.OutPatient;
import com.util.ApplicationUtil;
import com.exception.HospitalManagementException;
import com.management.AppointmentManagement;

public class AppointmentService {


    //Book Appointment 
    public static Appointment bookAppointment(String patientId, String modeOfAppointment) throws HospitalManagementException {


    	Appointment ap=null;
    	OutPatient op=OutPatientService.retrieveOutPatientDetails(patientId);
    	
        List<Doctor> doctorList = DoctorService.retrieveDoctorDetailsBySpecialization(op.getPreferredSpecialist());
        
        if (doctorList == null || doctorList.isEmpty()) {
            throw new HospitalManagementException("No doctors available for this Specialization");
        }
        
        else {
        	for (Doctor doctor : doctorList) {
        		
                LocalDate availableDate = doctor.getAvailableDate();
                LocalTime availableTime = doctor.getAvailableTime();

                LocalTime endOfDay = availableTime.plusHours(8); // Assume 8-hour workday
                LocalTime slot = availableTime;

                while (slot.isBefore(endOfDay)) {
                    boolean slotTaken = false;

                    List<Appointment> existingAppointments = AppointmentManagement.retrieveAppointmentsByDoctorIdDB(doctor.getDoctorId());
                    
                    for (Appointment appt : existingAppointments) {
                        if (appt.getAppointmentDate().equals(availableDate) && appt.getAppointmentTime().equals(slot)) {
                            slotTaken = true;
                            break;
                        }
                    }
                    slot = slot.plusMinutes(30); // Next 30-min slot
                    
                    if(!slotTaken) {
                    	String appointmentId=ApplicationUtil.generateAppointmentId();
                        String patientIdDB=op.getPatientId();
                        String doctorId=doctor.getDoctorId();
                        String doctorName=doctor.getDoctorName();
                        String specialization=doctor.getSpecialization();
                        LocalDate appointmentDate=doctor.getAvailableDate();
                        LocalTime appointmentTime=slot;
                        
                        ap=new Appointment(appointmentId, patientIdDB, doctorId, doctorName, specialization, appointmentDate, appointmentTime, modeOfAppointment);
                        
                        int rows=AppointmentManagement.insertAppointmentList(ap);
                        if(rows<=0) {
                        	throw new HospitalManagementException("Appointment Details not inserted in database");
                        }
                        return ap;
                    }
                    else {
                    	throw new HospitalManagementException("Already Appointed for this patient");
                    }
                }
               // throw new HospitalManagementException("No slots available");//it will not work in any case
            }
        	return ap;//it will not work in any case
        }
      // return ap; //it will not work in any case
    }

    // Retrieve appointment details by ID
    public static List<Appointment> retrieveAppointmentDetails(String patientId) throws HospitalManagementException {  	
 
    	ApplicationUtil.validateOutPatientId(patientId);
    	
    	List<Appointment> apList=AppointmentManagement.retrieveAppointmentDetailsFromDB(patientId);
    	if(apList==null) {
    		throw new HospitalManagementException("No Appointment Details available for this patient ID: "+patientId);
    	}
		return apList;
    }

	// Delete Appointment by Patient ID
    public static int deleteAppointmentDetailsFromDB(String patientId) throws HospitalManagementException {
        int rows=AppointmentManagement.deleteAppointmentDetailsFromDB(patientId);
        if(rows<=0) {
        	throw new HospitalManagementException("Appointment Details not deleted from database");
        }
        return rows;
        
    }
    
}