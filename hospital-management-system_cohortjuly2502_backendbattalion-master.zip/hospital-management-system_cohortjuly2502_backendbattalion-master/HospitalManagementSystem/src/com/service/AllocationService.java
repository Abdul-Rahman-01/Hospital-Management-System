
package com.service;

import java.time.*;

import com.exception.HospitalManagementException;
import com.model.Allocation;
import com.model.InPatient;
import com.util.ApplicationUtil;
import com.management.AllocationManagement;

public class AllocationService {

    private static int totalRooms=10;

    
    public static int bookAllocation(String patientId,String admiDate, String roomType) throws HospitalManagementException {
    	
    	String allocationId=ApplicationUtil.generateAllocationId();
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	
    	Allocation alloc=AllocationManagement.retrieveAllocationDetailsFromDB(patientId);
    	if(alloc!=null) {
    		if(alloc.getPatientId().equalsIgnoreCase(patientId)) {
        		throw new HospitalManagementException("Room already allocated for Patient ID: "+patientId);
        	}
    	}
    	
    	int roomCount=InPatientService.checkRoomType(roomType);
    	if(roomCount>totalRooms) {
    		throw new HospitalManagementException("No Rooms available for this Room Type");
    	}
    	
    	int roomNo=roomCount+1;
    	
    	LocalDate admissionDate=ApplicationUtil.parseLocalDate(admiDate);
    	
    	LocalDate dischargeDate=LocalDate.now();
    	
    	Period p=Period.between(admissionDate, dischargeDate);
    	int noOfDaysAdmitted=p.getDays();
    	
    	InPatient ip=InPatientService.retrieveInPatientDetails(patientId);
    	String treatment=ip.getTreatment();
    	
    	
    	
    	String wantFood=ip.getWantFood();
    	
    	Allocation al=new Allocation(allocationId, patientId, roomNo, noOfDaysAdmitted, admissionDate, dischargeDate, treatment, roomType, wantFood);
    	
    	int rows=AllocationManagement.insertAllocationList(al);
    	
    	InPatientService.updateInPatientRoomType(patientId, roomType);
    	
    	if(rows<=0) {
    		throw new HospitalManagementException("Allocation details not inserted");
    	}
    	return rows;
    }


    // 2. Retrieve Allocation Details
    public static Allocation retrieveAllocationDetails(String patientId) throws HospitalManagementException {
        ApplicationUtil.validateInPatientId(patientId);
        Allocation al= AllocationManagement.retrieveAllocationDetailsFromDB(patientId);
        if (al==null) {
            throw new HospitalManagementException("No allocation details found for patient: " + patientId);
        }
        return al;
    }

    // 3. Delete Allocation Details
    public static int deleteAllocationDetails(String patientId) throws HospitalManagementException {
        ApplicationUtil.validateInPatientId(patientId);
        int rows = AllocationManagement.deleteAllocationDetailsFromDB(patientId);
        if (rows <= 0) {
            throw new HospitalManagementException("Allocation details not deleted for Patient ID: " + patientId);
        }
        return rows;
    }
    
    public static int updateDischargeDate(String patientId,String disDate) throws HospitalManagementException{
    	ApplicationUtil.validateInPatientId(patientId);
    	
    	LocalDate dischargeDate=ApplicationUtil.parseLocalDate(disDate);
    	Allocation a=AllocationManagement.retrieveAllocationDetailsFromDB(patientId);
    	LocalDate admissionDate=a.getAdmissionDate();
    	
    	Period p=Period.between(admissionDate, dischargeDate);
    	int noOfDaysAdmitted=p.getDays();
    	
    	int row=AllocationManagement.updateDischargeDateDB(patientId, dischargeDate,noOfDaysAdmitted);
    	if(row<=0) {
    		throw new HospitalManagementException("Discharge date not Updated");
    	}
        return row;
    }
}