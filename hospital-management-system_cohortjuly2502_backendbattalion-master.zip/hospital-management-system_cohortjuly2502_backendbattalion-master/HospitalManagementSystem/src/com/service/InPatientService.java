package com.service;


import java.util.*;


import com.model.*;
import com.util.ApplicationUtil;
import com.management.InPatientManagement;
import com.exception.HospitalManagementException;

public class InPatientService {

    //Build InPatient List from Input
    public static List<InPatient> buildInPatientList(List<String> recordList) throws HospitalManagementException {
        List<InPatient> inPatientList = new ArrayList<>();

       // PATIENT_ID -generate
        //PATIENT_NAME PHONE_NUMBER   AGE GENDER MEDICAL_HISTORY PREFFERED_SPECIALIST 
        
        //MEDICINE_FEE PATIENT_TYPE  ADMISSION_FEES TREATMENT    WANT_FOOD 
        
        //name,phno,age,gender,medical_history,preff_specialist,medicine_fee,patient_type,admission_fee,treatment,wantfood

        int inPatientFromDB=ApplicationUtil.generateInPatientId();
        for (String record : recordList) {
            List<String> parsedDetail=ApplicationUtil.extractDetails(record);
            
            if(parsedDetail.size()<11) {
            	throw new HospitalManagementException("In Patient Details must contain 11 records");
            }
            
            inPatientFromDB++;
            String patientId="IP"+inPatientFromDB;
            
            String patientName=parsedDetail.get(0);
            
            ApplicationUtil.validatePhoneNumber(parsedDetail.get(1));
            long patientPhNo=Long.parseLong(parsedDetail.get(1));
            
            int age=Integer.parseInt(parsedDetail.get(2));
            ApplicationUtil.validateAge(age);
            
            String gender=parsedDetail.get(3);
            ApplicationUtil.validateGender(gender);
            		
            String medicalHistory=parsedDetail.get(4);
            
            String preferredSpecialist=parsedDetail.get(5);
            
            double medicineFee=Double.parseDouble(parsedDetail.get(6));
            ApplicationUtil.validateFee(medicineFee);
            
            
            String patientType=parsedDetail.get(7);
            
            double admissionFee=Double.parseDouble(parsedDetail.get(8));
            ApplicationUtil.validateFee(admissionFee);
               
            String treatment=parsedDetail.get(9);
            
//            String roomType=parsedDetail.get(10);
//            ApplicationUtil.validateRoomType(roomType);
            String roomType=null;
            
            String wantFood=parsedDetail.get(10);
            ApplicationUtil.validateFoodPreference(wantFood);
            
            InPatient ip=new InPatient(patientId, patientName, patientPhNo, age, gender, medicalHistory, preferredSpecialist, medicineFee, patientType, admissionFee, treatment, roomType, wantFood);

            inPatientList.add(ip);
        }
        return inPatientList;
    }

    //Add InPatient List to Database
    public static int addInPatientListToDB(List<String> recordList) throws HospitalManagementException {
        List<InPatient> inPatientList = buildInPatientList(recordList);
        int rows=InPatientManagement.insertInPatientListDB(inPatientList);
        if(rows>0) {
        	return rows;
        }
        else {
        	throw new HospitalManagementException("Failed to insert In Patient Details");
        }
    }
    
    // Check if ID exists 
    public static boolean checkInPatientId(String patientId) throws HospitalManagementException {
    	ApplicationUtil.validateInPatientId(patientId);
    	boolean flag=InPatientManagement.checkIdExistsDB(patientId);
    	if(flag==false) {
    		throw new HospitalManagementException("In Patient ID does not exists");
    	}
        return flag;
    }

    //Update InPatient Phone Number
    public static int updateInPatientPhoneNumber(String patientId, String newPhoneNumber)
            throws HospitalManagementException {
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	ApplicationUtil.validatePhoneNumber(newPhoneNumber);
    	
    	int row=InPatientManagement.updateInPatientPhoneNumberDB(patientId, Long.parseLong(newPhoneNumber));
    	if(row<=0) {
    		throw new HospitalManagementException("Patient Phone Number not Updated");
    	}
        return row;
    }

    //Update InPatient Room Type
    public static int updateInPatientRoomType(String patientId, String newRoomType)
            throws HospitalManagementException {
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	ApplicationUtil.validateRoomType(newRoomType);
    	
    	int row=InPatientManagement.updateInPatientRoomTypeDB(patientId, newRoomType);
    	if(row<=0) {
    		throw new HospitalManagementException("Patient Room Type not Updated");
    	}
        return row;
    }

    //Update InPatient Food Preference
    public static int updateInPatientFoodPreference(String patientId, String newFoodPref)
            throws HospitalManagementException {
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	ApplicationUtil.validateFoodPreference(newFoodPref);
    	
    	int row=InPatientManagement.updateInPatientFoodPreferenceDB(patientId, newFoodPref);
    	if(row<=0) {
    		throw new HospitalManagementException("Patient Food Preference not Updated");
    	}
        return row;
    }

    //Retrieve InPatient Details
    public static InPatient retrieveInPatientDetails(String patientId)
            throws HospitalManagementException {
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	
    	InPatient ip=InPatientManagement.retrieveInPatientDetailsDB(patientId);
    	if(ip==null) {
    		throw new HospitalManagementException("Patient not Found");
    	}
        return ip;
    }

    //Delete InPatient Details
    public static int deleteInPatientDetails(String patientId)
            throws HospitalManagementException{
    	
    	ApplicationUtil.validateInPatientId(patientId);
    	
    	int row=InPatientManagement.deleteInPatientDetailsFromDB(patientId);
    	
    	if(row<=0) {
    		throw new HospitalManagementException("Patient Id not deleted");
    	}
        return row;
    }
    
    public static int checkRoomType(String roomType) throws HospitalManagementException {
    	//ApplicationUtil.validateInPatientId(patientId);
    	
    	int roomCount=InPatientManagement.retrieveRoomCountByType(roomType);
    	return roomCount;
    }
    
//	public static void main (String args[]) throws SQLException {
//	//DoctorService doc=new DoctorService();
//	List<String> details=new ArrayList<String>();
//	Scanner sc=new Scanner(System.in);
//	
//	
//	System.out.println("ENter details: ");
//	//input name,fees,specialization,availableDate,time
//	String detail=sc.nextLine();
//	details.add(detail);
//	try {
//		int i=InPatientService.addInPatientListToDB(details);
//		System.out.println(i);
//		
//		System.out.println("Enter doctor id and fees , seperated");
//		String idFee=sc.nextLine();
//		
//		if(InPatientService.updateInPatientPhoneNumber(idFee.split(",")[0],idFee.split(",")[1])>0) {
//			System.out.println("ph no updated");
//		}
//		
//		idFee=sc.nextLine();
//		if(InPatientService.updateInPatientFoodPreference(idFee.split(",")[0],idFee.split(",")[1])>0) {
//			System.out.println("food pref updated");
//		}
//		
//		idFee=sc.nextLine();
//		if(InPatientService.updateInPatientRoomType(idFee.split(",")[0],idFee.split(",")[1])>0) {
//			System.out.println("room type updated");
//		}
//		
//		System.out.println("Enter to retrieve : ");
//		String id=sc.next();
//		Patient doc1=InPatientService.retrieveInPatientDetails(id);
//		System.out.println(doc1);
//		
//	} catch (HospitalManagementException e) {
//		// TODO Auto-generated catch block
//		System.out.println(e.getMessage());
//	}
//}

}
