package com.service;

import java.time.LocalDate;
import java.util.List;

import com.exception.HospitalManagementException;
import com.management.PaymentManagement;
import com.model.Appointment;
import com.model.Doctor;
import com.model.InPatient;
import com.model.OutPatient;
import com.model.Payment;
import com.util.ApplicationUtil;

public class PaymentService {

	private static final int privateRoom=5000;
	private static final int semiPrivateRoom=2500;
	private static final int normalRoom=1000;
	
	public static Payment buildPaymentObjects(String patientId,String modeOfPayment,double amount) throws HospitalManagementException{

		String paymentId=ApplicationUtil.generatePaymentId();
		if(patientId.startsWith("IP")) {
			ApplicationUtil.validateInPatientId(patientId);
			
			InPatient ip=InPatientService.retrieveInPatientDetails(patientId);
			
			String patientIdDB=ip.getPatientId();
			String patientName=ip.getPatientName();
			String patientType=ip.getPatientType();
			
			LocalDate paymentDate=LocalDate.now();
			
			return new Payment(paymentId,patientIdDB,patientName,patientType,paymentDate,modeOfPayment,amount);
		}
		else {
			ApplicationUtil.validateOutPatientId(patientId);
			
			OutPatient op=OutPatientService.retrieveOutPatientDetails(patientId);
			
			String patientIdDB=op.getPatientId();
			String patientName=op.getPatientName();
			String patientType=op.getPatientType();
			
			LocalDate paymentDate=LocalDate.now();
			
			return new Payment(paymentId,patientIdDB,patientName,patientType,paymentDate,modeOfPayment,amount);
		}
	}
	
	public static int generateBill(String patientId,double amount,String modeOfPayment) throws HospitalManagementException{
		Payment p=buildPaymentObjects(patientId, modeOfPayment, amount);
		int rows=PaymentManagement.insertPaymentDB(p);
		if(rows<=0) {
			throw new HospitalManagementException("Payment details not added in database");
		}
		return rows;
	}
	
	public static double calculateBill(String patientId) throws HospitalManagementException {
		
		if(patientId.startsWith("IP")) {
			double amount=calculateInPatientBill(patientId);
			return amount;
			
		}
		else if(patientId.startsWith("OP")) {
			double amount=calculateOutPatientBill(patientId);
			return amount;
		}
		else {
			throw new HospitalManagementException("Entered Patient ID is invalid. Patient ID should starts with IPXXXX or OPXXXX");
		}
	}

	private static double calculateInPatientBill(String patientId) throws HospitalManagementException {

		InPatient ip=InPatientService.retrieveInPatientDetails(patientId);
		
		//Calculates the bill amount for InPatients
		//considering factors like treatment, room type, food preference, and admission duration
		
		double amount=ip.getMedicineFee()+ip.getAdmissionFees();
		if(ip.getRoomType().equalsIgnoreCase("private")) {
			amount+=privateRoom;
		}
		else if(ip.getRoomType().equalsIgnoreCase("semi-private")) {
			amount+=semiPrivateRoom;
		}
		else {
			amount+=normalRoom;
		}
		return amount;
	}
	
	private static double calculateOutPatientBill(String patientId) throws HospitalManagementException {
		
		//Calculates the bill amount for OutPatients based on details like 
		//doctor fees, medicine fees, and registration fees.
		OutPatient op=OutPatientService.retrieveOutPatientDetails(patientId);
		List<Appointment> appointmentList=AppointmentService.retrieveAppointmentDetails(patientId);
		
		double amount=op.getMedicineFee()+op.getRegistrationFees();
		
		for(Appointment ap:appointmentList) {
			String doctorId=ap.getDoctorId();
			
			Doctor d=DoctorService.retrieveDoctorDetails(doctorId);
			double doctorFee=d.getDoctorFee();
			amount+=doctorFee;
		}
		return amount;
	}
	
	public static List<Payment> retrievePaymentDetailsByPatientId(String patientId) throws HospitalManagementException {
		if(patientId.startsWith("IP") || patientId.startsWith("OP")) {
			List<Payment> paymentList=PaymentManagement.retrievePaymentDetailsByPatientDB(patientId);
			return paymentList;
		}
		else {
			throw new HospitalManagementException("Invalid Patient ID");
		}
	}
	
	public static Payment retrievePaymentDetailsByPaymentId(String paymentId) throws HospitalManagementException {
		ApplicationUtil.validatePaymentId(paymentId);
		
		Payment p=PaymentManagement.retrievePaymentDetailsByPaymentIdDB(paymentId);
		return p;
	}
}
